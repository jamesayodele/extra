<!DOCTYPE html>
<html>
<head>
	<title>thisisjames.com.ng</title>
</head>
<?php
define("HOST","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DBNAME","thisisj5_demo");
$conn = mysqli_connect(HOST,USERNAME,PASSWORD,DBNAME);
if (!$conn) {
	# code...
	echo "db not connected";
}
if (isset($_POST['create'])) {
	$username =mysqli_real_escape_string($conn,$_POST['username']);
		$password =mysqli_real_escape_string($conn,$_POST['password']);
		$db = "INSERT INTO users(username,password) VALUES ('$username','$password')";
		$result =mysqli_query($conn,$db);
		if ($result) {
			# code...
			echo "sucess";
		}

}

?>
<body>
<form action="register.php" method="post">
	<input type="text" name="username" value="USERNAME" placeholder="please enter username"><br>
	<input type="password" name="password" placeholder="please enter your password">
	<input type="submit" name="create" value="REGISTER">
</form>
<a href="login.php">GO AND LOGIN </a>
</body>
</html>