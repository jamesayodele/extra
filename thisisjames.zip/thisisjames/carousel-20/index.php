<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Arbutus+Slab&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="css/animate.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>thisisjames.com.ng</title>
  </head>
  <body>
  

  <div class="content">
    
    <div class="container">
      <h2 class="my-5 text-center text-white">Educational Site</h2>
    </div>

    <div class="site-blocks-cover">
      <div class="img-wrap">
        <div class="owl-carousel slide-one-item hero-slider">
          <div class="slide">
            <img src="images/hero_1.jpg" alt="Free Website Template by Free-Template.co">  
          </div>
          <div class="slide">
            <img src="images/hero_2.jpg" alt="Free Website Template by Free-Template.co">  
          </div>
          <div class="slide">
            <img src="images/hero_3.jpg" alt="Free Website Template by Free-Template.co">  
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-6 ml-auto align-self-center">
            <div class="intro">
              <div class="heading">
                <h1 class="text-white font-weight-bold">The Official Site</h1>
              </div>
              <div class="text sub-text">
                <p>You are welcome to thisisjames.com.ng,click on the button below to login into the site.</p>
                <p><a href="login.php" target="_blank" class="btn btn-outline-primary btn-md btn-pill">Login</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div> <!-- END .site-blocks-cover -->
  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>