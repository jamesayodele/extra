<?php
define("HOST","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DBNAME","thisisj5_demo");
$conn = mysqli_connect(HOST,USERNAME,PASSWORD,DBNAME);
if (!$conn) {
	# code...
	echo "db not connected";
}
    if (isset($_POST['login'])) {
    	# code...
    
	$username =mysqli_real_escape_string($conn,$_POST['username']);
		$password =mysqli_real_escape_string($conn,$_POST['password']);
$retrieved ="SELECT * FROM users WHERE username ='$username' AND password ='$password'";
$result =mysqli_query($conn,$retrieved);
if (mysqli_num_rows($result) > 0) {
    header("Location:services.php");
}else{
    echo "cannot";
}

}
?>




<?php
if (isset($_POST['register'])) {
header("Location:register.php");	# code...
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>

<body>
<form action="login.php" method="post">
	<input type="text" name="username" value="USERNAME" placeholder="please enter username"><br>
	<input type="password" name="password" placeholder="please enter your password">
	<input type="submit" name="login" value="LOGIN">
		<input type="submit" name="register" value="REGISTER">


</form>
</body>
</html>